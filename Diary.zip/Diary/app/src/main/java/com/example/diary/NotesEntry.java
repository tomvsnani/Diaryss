package com.example.diary;

import androidx.room.Entity;

@Entity
public class NotesEntry {
}
